<?php 
error_reporting(0);
session_start();

$con=mysqli_connect('localhost','root','','project') or die('Connection Failed');

?>